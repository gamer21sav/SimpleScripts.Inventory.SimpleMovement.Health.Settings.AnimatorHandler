using UnityEngine;
using UnityEngine.UI;

public class TogglePanel : MonoBehaviour
{
    public GameObject targetObject; // Assign in Inspector
    public GameObject[] otherObjectsToToggle; // Optional: other objects to toggle
    public bool initialState = false;

    private CanvasGroup canvasGroup;
    private bool isToggled;

    void Start()
    {
        canvasGroup = GetComponent<CanvasGroup>();
        if (canvasGroup == null)
        {
            canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }

        isToggled = initialState;
        UpdateState();
    }

    public void Toggle()
    {
        isToggled = !isToggled;
        UpdateState();
    }

    void UpdateState()
    {
        // Toggle the main target object
        gameObject.SetActive(isToggled);

        // Toggle any array of other objects
        if (otherObjectsToToggle != null)
        {
            foreach (GameObject obj in otherObjectsToToggle)
            {
                if (obj != null)
                {
                    obj.SetActive(isToggled);
                }
            }
        }

        // Animate the CanvasGroup alpha for smooth sliding
        if (canvasGroup != null)
        {
            canvasGroup.alpha = isToggled ? 1f : 0f;
        }
    }

    // Optional: Auto-toggle when this object is clicked
    void OnClick()
    {
        Toggle();
    }

    // Optional: Toggle on a key press
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            Toggle();
        }
    }
}
